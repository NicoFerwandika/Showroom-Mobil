﻿Imports MySql.Data.MySqlClient

Public Class FormMobil
    Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=db_showroom")
    Dim cmd As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim dt As DataTable
    Dim id_mobil As Integer = 0

    Private Sub FormMobil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tampilMobil()
        clearForm()
    End Sub

    Sub tampilMobil()
        Try
            conn.Open()
            da = New MySqlDataAdapter("SELECT * FROM mobil", conn)
            dt = New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
            conn.Close()
        Catch ex As Exception
            MsgBox("Gagal Menampilkan Data: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Sub clearForm()
        For Each ctrl As Control In Me.Controls
            If TypeOf ctrl Is TextBox Then ctrl.Text = ""
        Next
        Button1.Enabled = True ' Tambah
        Button2.Enabled = False ' Edit
        Button3.Enabled = False ' Hapus
        id_mobil = 0
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("Semua field harus diisi!")
            Exit Sub
        End If

        Try
            conn.Open()
            cmd = New MySqlCommand("INSERT INTO mobil (merk, tipe, warna, tahun, harga) VALUES (@merk,@tipe,@warna,@tahun,@harga)", conn)
            cmd.Parameters.AddWithValue("@merk", TextBox1.Text)
            cmd.Parameters.AddWithValue("@tipe", TextBox2.Text)
            cmd.Parameters.AddWithValue("@warna", TextBox3.Text)
            cmd.Parameters.AddWithValue("@tahun", TextBox4.Text)
            cmd.Parameters.AddWithValue("@harga", TextBox5.Text)
            cmd.ExecuteNonQuery()
            conn.Close()

            MsgBox("Data mobil berhasil ditambahkan")
            tampilMobil()
            clearForm()
        Catch ex As Exception
            MsgBox("Gagal Menambah Data: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            id_mobil = DataGridView1.CurrentRow.Cells(0).Value
            TextBox1.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString()
            TextBox2.Text = DataGridView1.CurrentRow.Cells(2).Value.ToString()
            TextBox3.Text = DataGridView1.CurrentRow.Cells(3).Value.ToString()
            TextBox4.Text = DataGridView1.CurrentRow.Cells(4).Value.ToString()
            TextBox5.Text = DataGridView1.CurrentRow.Cells(5).Value.ToString()
            Button1.Enabled = False
            Button2.Enabled = True
            Button3.Enabled = True
        Catch ex As Exception
            MsgBox("Gagal memilih data: " & ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id_mobil = 0 Then MsgBox("Pilih data terlebih dahulu") : Exit Sub

        Try
            conn.Open()
            cmd = New MySqlCommand("UPDATE mobil SET merk=@merk, tipe=@tipe, warna=@warna, tahun=@tahun, harga=@harga WHERE id_mobil=@id", conn)
            cmd.Parameters.AddWithValue("@merk", TextBox1.Text)
            cmd.Parameters.AddWithValue("@tipe", TextBox2.Text)
            cmd.Parameters.AddWithValue("@warna", TextBox3.Text)
            cmd.Parameters.AddWithValue("@tahun", TextBox4.Text)
            cmd.Parameters.AddWithValue("@harga", TextBox5.Text)
            cmd.Parameters.AddWithValue("@id", id_mobil)
            cmd.ExecuteNonQuery()
            conn.Close()

            MsgBox("Data berhasil diubah!")
            tampilMobil()
            clearForm()
        Catch ex As Exception
            MsgBox("Gagal update: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If id_mobil = 0 Then MsgBox("Pilih data yang akan dihapus") : Exit Sub

        If MsgBox("Hapus data ini?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Try
                conn.Open()
                cmd = New MySqlCommand("DELETE FROM mobil WHERE id_mobil=@id", conn)
                cmd.Parameters.AddWithValue("@id", id_mobil)
                cmd.ExecuteNonQuery()
                conn.Close()

                MsgBox("Data berhasil dihapus!")
                tampilMobil()
                clearForm()
            Catch ex As Exception
                MsgBox("Gagal hapus data: " & ex.Message)
                conn.Close()
            End Try
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        clearForm()
    End Sub

    ' Validasi angka untuk tahun & harga
    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress, TextBox5.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    ' === CONTEXT MENU STRIP ===
    Private Sub EditDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ContextMenuStrip1.Click
        Call DataGridView1_CellClick(Nothing, Nothing)
    End Sub

    Private Sub HapusDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HapusToolStripMenuItem.Click
        Call Button3_Click(Nothing, Nothing)
    End Sub
End Class
