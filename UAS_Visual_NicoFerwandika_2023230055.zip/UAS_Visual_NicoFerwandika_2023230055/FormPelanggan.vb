﻿Imports MySql.Data.MySqlClient

Public Class FormPelanggan
    Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=db_showroom")
    Dim cmd As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim dt As DataTable
    Dim id_pelanggan As Integer = 0

    Private Sub FormPelanggan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tampilPelanggan()
        clearForm()
    End Sub

    Sub tampilPelanggan()
        Try
            conn.Open()
            da = New MySqlDataAdapter("SELECT * FROM pelanggan", conn)
            dt = New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
            conn.Close()
        Catch ex As Exception
            MsgBox("Gagal tampil: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Sub clearForm()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        id_pelanggan = 0
        Button1.Enabled = True
        Button2.Enabled = False
        Button3.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Data belum lengkap!")
            Exit Sub
        End If

        Try
            conn.Open()
            cmd = New MySqlCommand("INSERT INTO pelanggan (nama, alamat, no_hp) VALUES (@nama, @alamat, @hp)", conn)
            cmd.Parameters.AddWithValue("@nama", TextBox1.Text)
            cmd.Parameters.AddWithValue("@alamat", TextBox2.Text)
            cmd.Parameters.AddWithValue("@hp", TextBox3.Text)
            cmd.ExecuteNonQuery()
            conn.Close()

            MsgBox("Data pelanggan ditambahkan!")
            tampilPelanggan()
            clearForm()
        Catch ex As Exception
            MsgBox("Gagal tambah: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id_pelanggan = 0 Then MsgBox("Pilih data!") : Exit Sub

        Try
            conn.Open()
            cmd = New MySqlCommand("UPDATE pelanggan SET nama=@nama, alamat=@alamat, no_hp=@hp WHERE id_pelanggan=@id", conn)
            cmd.Parameters.AddWithValue("@nama", TextBox1.Text)
            cmd.Parameters.AddWithValue("@alamat", TextBox2.Text)
            cmd.Parameters.AddWithValue("@hp", TextBox3.Text)
            cmd.Parameters.AddWithValue("@id", id_pelanggan)
            cmd.ExecuteNonQuery()
            conn.Close()

            MsgBox("Data pelanggan diubah!")
            tampilPelanggan()
            clearForm()
        Catch ex As Exception
            MsgBox("Gagal update: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If id_pelanggan = 0 Then MsgBox("Pilih data!") : Exit Sub

        If MsgBox("Yakin hapus data?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Try
                conn.Open()
                cmd = New MySqlCommand("DELETE FROM pelanggan WHERE id_pelanggan=@id", conn)
                cmd.Parameters.AddWithValue("@id", id_pelanggan)
                cmd.ExecuteNonQuery()
                conn.Close()

                MsgBox("Data pelanggan dihapus.")
                tampilPelanggan()
                clearForm()
            Catch ex As Exception
                MsgBox("Gagal hapus: " & ex.Message)
                conn.Close()
            End Try
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        clearForm()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            id_pelanggan = DataGridView1.CurrentRow.Cells(0).Value
            TextBox1.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString()
            TextBox2.Text = DataGridView1.CurrentRow.Cells(2).Value.ToString()
            TextBox3.Text = DataGridView1.CurrentRow.Cells(3).Value.ToString()
            Button1.Enabled = False
            Button2.Enabled = True
            Button3.Enabled = True
        Catch ex As Exception
            MsgBox("Pilih data error: " & ex.Message)
        End Try
    End Sub

    ' === CONTEXT MENU ===
    Private Sub EditDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditToolStripMenuItem.Click
        Call DataGridView1_CellClick(Nothing, Nothing)
    End Sub

    Private Sub HapusDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HapusToolStripMenuItem.Click
        Call Button3_Click(Nothing, Nothing)
    End Sub
End Class
