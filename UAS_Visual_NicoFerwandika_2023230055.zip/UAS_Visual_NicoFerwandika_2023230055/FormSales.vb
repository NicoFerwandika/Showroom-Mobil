﻿Imports MySql.Data.MySqlClient

Public Class FormSales
    Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=db_showroom")
    Dim cmd As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim dt As DataTable
    Dim id_sales As Integer = 0

    Private Sub FormSales_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tampilSales()
        clearForm()
    End Sub

    Sub tampilSales()
        Try
            conn.Open()
            da = New MySqlDataAdapter("SELECT * FROM sales", conn)
            dt = New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
            conn.Close()
        Catch ex As Exception
            MsgBox("Gagal tampil: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Sub clearForm()
        TextBox1.Clear()
        TextBox2.Clear()
        id_sales = 0
        Button1.Enabled = True
        Button2.Enabled = False
        Button3.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Lengkapi data dulu!")
            Exit Sub
        End If

        Try
            conn.Open()
            cmd = New MySqlCommand("INSERT INTO sales (nama, no_hp) VALUES (@nama, @no_hp)", conn)
            cmd.Parameters.AddWithValue("@nama", TextBox1.Text)
            cmd.Parameters.AddWithValue("@no_hp", TextBox2.Text)
            cmd.ExecuteNonQuery()
            conn.Close()

            MsgBox("Data sales berhasil ditambahkan")
            tampilSales()
            clearForm()
        Catch ex As Exception
            MsgBox("Gagal tambah: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            id_sales = DataGridView1.CurrentRow.Cells(0).Value
            TextBox1.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString()
            TextBox2.Text = DataGridView1.CurrentRow.Cells(2).Value.ToString()
            Button1.Enabled = False
            Button2.Enabled = True
            Button3.Enabled = True
        Catch ex As Exception
            MsgBox("Klik data error: " & ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id_sales = 0 Then MsgBox("Pilih data!") : Exit Sub

        Try
            conn.Open()
            cmd = New MySqlCommand("UPDATE sales SET nama=@nama, no_hp=@no_hp WHERE id_sales=@id", conn)
            cmd.Parameters.AddWithValue("@nama", TextBox1.Text)
            cmd.Parameters.AddWithValue("@no_hp", TextBox2.Text)
            cmd.Parameters.AddWithValue("@id", id_sales)
            cmd.ExecuteNonQuery()
            conn.Close()

            MsgBox("Data sales berhasil diubah!")
            tampilSales()
            clearForm()
        Catch ex As Exception
            MsgBox("Update gagal: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If id_sales = 0 Then MsgBox("Pilih data!") : Exit Sub

        If MsgBox("Hapus data ini?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Try
                conn.Open()
                cmd = New MySqlCommand("DELETE FROM sales WHERE id_sales=@id", conn)
                cmd.Parameters.AddWithValue("@id", id_sales)
                cmd.ExecuteNonQuery()
                conn.Close()

                MsgBox("Data sales dihapus!")
                tampilSales()
                clearForm()
            Catch ex As Exception
                MsgBox("Hapus gagal: " & ex.Message)
                conn.Close()
            End Try
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        clearForm()
    End Sub

    ' === CONTEXT MENU ===
    Private Sub EditDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditToolStripMenuItem.Click
        Call DataGridView1_CellClick(Nothing, Nothing)
    End Sub

    Private Sub HapusDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HapusToolStripMenuItem.Click
        Call Button3_Click(Nothing, Nothing)
    End Sub
End Class
