﻿Imports System.Reflection.Emit

Public Class FormUtama
    Private Sub FormMainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set form sebagai MDI Parent
        Me.IsMdiContainer = True
        Me.Text = "Showroom Mobil - Menu Utama"
        Me.WindowState = FormWindowState.Maximized

        ' Ubah label info login
        Label1.Text = "Selamat datang, [user] di Showroom Mobil Kami"
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 10, FontStyle.Bold)
        Label1.ForeColor = Color.DarkBlue
        Label1.Location = New Point(20, 30)

        ' Inisialisasi jam
        Timer1.Interval = 1000
        Timer1.Start()

        ' Atur MenuStrip
        MenuStrip1.Items.Clear()

        ' === MASTER DATA ===
        Dim menuMaster As New ToolStripMenuItem("Master Data")
        Dim menuMobil As New ToolStripMenuItem("Data Mobil")
        Dim menuPelanggan As New ToolStripMenuItem("Data Pelanggan")
        Dim menuSales As New ToolStripMenuItem("Data Sales")

        AddHandler menuMobil.Click, AddressOf bukaFormMobil
        AddHandler menuPelanggan.Click, AddressOf bukaFormPelanggan
        AddHandler menuSales.Click, AddressOf bukaFormSales

        menuMaster.DropDownItems.Add(menuMobil)
        menuMaster.DropDownItems.Add(menuPelanggan)
        menuMaster.DropDownItems.Add(menuSales)

        ' === TRANSAKSI ===
        Dim menuTransaksi As New ToolStripMenuItem("Transaksi")
        Dim menuPenjualan As New ToolStripMenuItem("Penjualan Mobil")
        AddHandler menuPenjualan.Click, AddressOf bukaFormTransaksi
        menuTransaksi.DropDownItems.Add(menuPenjualan)

        ' === LOGOUT ===
        Dim menuLogout As New ToolStripMenuItem("Logout")
        AddHandler menuLogout.Click, AddressOf logoutAplikasi

        ' === Tambahkan semua menu ke MenuStrip ===
        MenuStrip1.Items.Add(menuMaster)
        MenuStrip1.Items.Add(menuTransaksi)
        MenuStrip1.Items.Add(menuLogout)

        ' === Tampilkan MenuStrip di Form ===
        Me.MainMenuStrip = MenuStrip1
        Me.Controls.Add(MenuStrip1)
    End Sub

    ' Tampilkan jam
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Text = "Toko Laundry - " & TimeOfDay.ToString("HH:mm:ss")
    End Sub

    ' Aksi buka form pelanggan
    Private Sub bukaFormMobil()
        FormMobil.MdiParent = Me
        FormMobil.Show()
        FormMobil.Focus()
    End Sub

    ' Aksi buka form layanan
    Private Sub bukaFormPelanggan()
        FormPelanggan.MdiParent = Me
        FormPelanggan.Show()
        FormPelanggan.Focus()
    End Sub

    ' Aksi buka form transaksi
    Private Sub bukaFormTransaksi()
        FormTransaksi.MdiParent = Me
        FormTransaksi.Show()
        FormTransaksi.Focus()
    End Sub

    ' Aksi buka form laporan
    Private Sub bukaFormSales()
        FormSales.MdiParent = Me
        FormSales.Show()
        FormSales.Focus()
    End Sub

    ' Aksi logout
    Private Sub logoutAplikasi()
        If MsgBox("Yakin ingin logout?", MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
            Me.Hide()
            FormLogin.Show()
        End If
    End Sub
End Class