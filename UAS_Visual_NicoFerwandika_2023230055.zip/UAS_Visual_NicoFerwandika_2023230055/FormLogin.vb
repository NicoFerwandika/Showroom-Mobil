﻿Imports MySql.Data.MySqlClient

Public Class FormLogin
    Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=db_showroom")
    Dim cmd As MySqlCommand
    Dim rd As MySqlDataReader

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Username dan Password wajib diisi!")
            Exit Sub
        End If

        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT * FROM users WHERE username=@username AND password=@password", conn)
            cmd.Parameters.AddWithValue("@username", TextBox1.Text)
            cmd.Parameters.AddWithValue("@password", TextBox2.Text)
            rd = cmd.ExecuteReader()

            If rd.HasRows Then
                rd.Read()
                Dim role As String = rd("role").ToString()

                MsgBox("Login berhasil sebagai " & role)

                ' Simpan session/variabel global jika perlu
                ' My.Settings.username = rd("username")
                ' My.Settings.Save()

                ' Buka form utama
                FormUtama.Show()
                Me.Hide()
            Else
                MsgBox("Username atau password salah!")
            End If

            conn.Close()
        Catch ex As Exception
            MsgBox("Login error: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox2.PasswordChar = "*"
    End Sub
End Class
