﻿Imports MySql.Data.MySqlClient

Public Class FormTransaksi
    Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=db_showroom")
    Dim cmd As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim dt As DataTable
    Dim id_transaksi As Integer = 0

    Private Sub FormTransaksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadCombo()
        tampilTransaksi()
        clearForm()
    End Sub

    Sub loadCombo()
        ' Combo Mobil
        ComboBox1.Items.Clear()
        cmd = New MySqlCommand("SELECT id_mobil, merk FROM mobil", conn)
        conn.Open()
        Dim rd = cmd.ExecuteReader()
        While rd.Read()
            ComboBox1.Items.Add(rd("id_mobil") & " - " & rd("merk"))
        End While
        conn.Close()

        ' Combo Pelanggan
        ComboBox2.Items.Clear()
        cmd = New MySqlCommand("SELECT id_pelanggan, nama FROM pelanggan", conn)
        conn.Open()
        rd = cmd.ExecuteReader()
        While rd.Read()
            ComboBox2.Items.Add(rd("id_pelanggan") & " - " & rd("nama"))
        End While
        conn.Close()

        ' Combo Sales
        ComboBox3.Items.Clear()
        cmd = New MySqlCommand("SELECT id_sales, nama FROM sales", conn)
        conn.Open()
        rd = cmd.ExecuteReader()
        While rd.Read()
            ComboBox3.Items.Add(rd("id_sales") & " - " & rd("nama"))
        End While
        conn.Close()
    End Sub

    Sub tampilTransaksi()
        Try
            conn.Open()
            da = New MySqlDataAdapter("SELECT transaksi.id_transaksi, mobil.merk, pelanggan.nama, sales.nama AS nama_sales, transaksi.tanggal, transaksi.harga FROM transaksi JOIN mobil ON transaksi.id_mobil=mobil.id_mobil JOIN pelanggan ON transaksi.id_pelanggan=pelanggan.id_pelanggan JOIN sales ON transaksi.id_sales=sales.id_sales", conn)
            dt = New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
            conn.Close()
        Catch ex As Exception
            MsgBox("Gagal tampil transaksi: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Sub clearForm()
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        TextBox1.Text = ""
        DateTimePicker1.Value = Date.Now
        id_transaksi = 0
    End Sub

    Function AmbilID(ByVal teksCombo As String) As Integer
        If teksCombo = "" Then Return 0
        Return Convert.ToInt32(teksCombo.Split("-")(0).Trim())
    End Function

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        ' Ambil harga mobil
        Dim idMobil = AmbilID(ComboBox1.Text)
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT harga FROM mobil WHERE id_mobil=@id", conn)
            cmd.Parameters.AddWithValue("@id", idMobil)
            Dim harga = cmd.ExecuteScalar()
            TextBox1.Text = harga.ToString()
            conn.Close()
        Catch ex As Exception
            MsgBox("Gagal ambil harga: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.Text = "" Or ComboBox2.Text = "" Or ComboBox3.Text = "" Then
            MsgBox("Lengkapi semua data!")
            Exit Sub
        End If

        Try
            conn.Open()
            cmd = New MySqlCommand("INSERT INTO transaksi (id_mobil, id_pelanggan, id_sales, tanggal, harga) VALUES (@mobil, @pel, @sales, @tgl, @harga)", conn)
            cmd.Parameters.AddWithValue("@mobil", AmbilID(ComboBox1.Text))
            cmd.Parameters.AddWithValue("@pel", AmbilID(ComboBox2.Text))
            cmd.Parameters.AddWithValue("@sales", AmbilID(ComboBox3.Text))
            cmd.Parameters.AddWithValue("@tgl", DateTimePicker1.Value)
            cmd.Parameters.AddWithValue("@harga", TextBox1.Text)
            cmd.ExecuteNonQuery()
            conn.Close()

            MsgBox("Transaksi berhasil disimpan")
            tampilTransaksi()
            clearForm()
        Catch ex As Exception
            MsgBox("Gagal tambah transaksi: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        ' Boleh dikembangkan untuk Edit nanti
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MsgBox("Hapus fitur belum diaktifkan")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        clearForm()
    End Sub
End Class
